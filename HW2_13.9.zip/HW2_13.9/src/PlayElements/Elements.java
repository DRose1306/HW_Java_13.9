package PlayElements;

public enum Elements {
    ROCK, //1
    SCISSORS, //2
    PAPPER //3
}
