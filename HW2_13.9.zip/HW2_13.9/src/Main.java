import java.util.Random;
import java.util.Scanner;

import PlayElements.Elements;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        Random rnd = new Random();

        Elements[] elements = Elements.values();

        System.out.println("Добро пожаловать в игру Камень, Ножницы, Бумага!");
        do {
            System.out.println("Выберите ваш ход: 1 - ROCK, 2 - SCISSORS, 3 - PAPPER");
            int userChoice = scn.nextInt();scn.nextLine();
            Elements user = elements[userChoice - 1];
            Elements npc = elements[rnd.nextInt(3)];

            System.out.println("Ваш выбор: " + user);
            System.out.println("Выбор компьютера: " + npc);
            if (user == npc) {
                System.out.println("Ничья!");
            } else if ((user == Elements.ROCK && npc == Elements.SCISSORS) ||
                    (user == Elements.SCISSORS && npc == Elements.PAPPER) ||
                    (user == Elements.PAPPER && npc == Elements.ROCK)) {
                System.out.println("Вы победили!");
            } else {
                System.out.println("Компьютер победил!");
            }
            System.out.println("хотите продолжить Yes No");
        }while (!"No".equalsIgnoreCase(scn.nextLine()));
    }
}
//Задание 2.
//Напишите консольную игру «Камень, ножницы, бумага». Пользователь вводит
//свой выбор (в виде строки или числа). Программа случайным образом делает
//свой выбор и выводит на экран. Далее программа показывает, кто победитель –
//пользователь или программа.