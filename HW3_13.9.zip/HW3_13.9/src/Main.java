import MonthsOfTheYear.Months;


public class Main {
    public static void main(String[] args) {
        Months months = Months.JUNE;
        String season = switch (months){
            case JANUARY -> "Winter";
            case FEBRUARY -> "Winter";
            case DECEMBER -> "Winter";
            case MARCH -> "Spring";
            case APRIL -> "Spring";
            case MAY -> "Spring";
            case JUNE -> "Sommer";
            case JULY -> "Sommer";
            case AUGUST -> "Sommer";
            case SEPTEMBER -> "Autumn";
            case OKTOBER -> "Autumn";
            case NOVEMBER -> "Autumn";
            default -> "посмотрите мультик 12 месяцев";

        };
        System.out.println("месяц " + months + " является месяцем из сезона " + season);
    }
}
//Создайте Enum месяцев года.
//Задана переменная месяца. Программа должна вывести название сезона для данного месяца
//(зима, весна, лето, осень).