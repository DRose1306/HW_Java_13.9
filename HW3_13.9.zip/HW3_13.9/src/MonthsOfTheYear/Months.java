package MonthsOfTheYear;

public enum Months {
    JANUARY,
    FEBRUARY,
    MARCH,
    APRIL,
    MAY,
    JUNE,
    JULY,
    AUGUST,
    SEPTEMBER,
    OKTOBER,
    NOVEMBER,
    DECEMBER
}
