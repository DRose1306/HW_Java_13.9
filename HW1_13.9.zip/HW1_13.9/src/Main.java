import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Введите год");
        int year = scn.nextInt();
        String wedding = switch (year) {
            case 1 -> "ситцевая";
            case 2 -> "бумажная";
            case 3 -> "кожаная";
            case 4 -> "льняная";
            case 5 -> "деревянная";
            case 6 -> "чугунная";
            case 7 -> "медная";
            case 8 -> "жестяная";
            case 9 -> "фаянсовая";
            case 10 -> "оловянная";
            default -> "у вас еще не была";
        };
        System.out.println(wedding + (" свадьба"));
    }
}
//Задание 1.
//Пользователь вводит, сколько лет он состоит в браке. Программа должна
//вывести, какая годовщина свадьбы будет у пользователя следующей (бумажная,
//ситцевая, чугунная, серебряная и.д.). Не обязательно указывать все годовщины,
//достаточно 10-15. Узнать про годовщины можно, например, здесь